package EXCEPTION;


@SuppressWarnings("serial")
public class TTBException extends Exception {
	public TTBException(String message) {
		super(message);
	}

}
